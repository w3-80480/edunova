const db = require('../config/db');

// Get all users
exports.getAllUsers = (req, res) => {
  const sql = 'SELECT * FROM users';
  db.query(sql, (err, results) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json(results);
    }
  });
};

// Get user by ID
exports.getUserById = (req, res) => {
  const sql = 'SELECT * FROM users WHERE id = ?';
  db.query(sql, [req.params.id], (err, result) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json(result);
    }
  });
};

// Add new user
exports.addUser = (req, res) => {
  const { name, username, status, role, email, teams } = req.body;
  const sql = 'INSERT INTO users (name, username, status, role, email, teams) VALUES (?, ?, ?, ?, ?, ?)';
  db.query(sql, [name, username, status, role, email, teams.join(',')], (err, result) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json({ message: 'User added successfully', userId: result.insertId });
    }
  });
};

// Update user
exports.updateUser = (req, res) => {
  const { name, username, status, role, email, teams } = req.body;
  const sql = 'UPDATE users SET name = ?, username = ?, status = ?, role = ?, email = ?, teams = ? WHERE id = ?';
  db.query(sql, [name, username, status, role, email, teams.join(','), req.params.id], (err) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json({ message: 'User updated successfully' });
    }
  });
};

// Delete user
exports.deleteUser = (req, res) => {
  const sql = 'DELETE FROM users WHERE id = ?';
  db.query(sql, [req.params.id], (err) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json({ message: 'User deleted successfully' });
    }
  });
};
